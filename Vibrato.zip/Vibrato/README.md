# Vibrato Hair Studio
Website I created for my friends hair studio.  I was learning Bootstrap at the time so that's what was used mostly.
